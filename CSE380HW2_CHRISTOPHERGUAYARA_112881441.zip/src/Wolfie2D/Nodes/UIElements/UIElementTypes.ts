export enum UIElementType {
	BUTTON = "BUTTON",
	LABEL = "LABEL",
	SLIDER = "SLIDER",
	TEXT_INPUT = "TEXTINPUT"
}